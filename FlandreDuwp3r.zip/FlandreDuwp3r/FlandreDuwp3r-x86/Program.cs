using System;

namespace FlandreDuwp3r;

static class Program {
	[STAThread]
	static void Main() {
		FlandreDuwp3r.Program.Main();
	}
}
