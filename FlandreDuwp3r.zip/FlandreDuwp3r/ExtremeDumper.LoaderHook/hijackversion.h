#pragma once

#include <windows.h>

BOOL APIENTRY HijackDllMain(HMODULE hModule, DWORD dwReason, PVOID pvReserved);
