//////////////////////////////////////////////////////////////////////////////
//
//  Unit Test Main (main.cpp of unittests.exe)
//
//  Microsoft Research Detours Package
//
//  Copyright (c) Microsoft Corporation.  All rights reserved.
//
#define CATCH_CONFIG_MAIN
#include "catch.hpp"
